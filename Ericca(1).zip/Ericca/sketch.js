
// Game constants
const TILE_SIZE = 40;
const PLAYER_SIZE = 30;
const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const PLAYER_SPEED = 5;
const ENEMY_SPEED = 2;
const PROJECTILE_SPEED = 7;
const COIN_SIZE = 20;
const COIN_ROTATION_SPEED = 0.05;
const INVINCIBILITY_DURATION = 1000; // 1 second
const PARTICLE_LIFETIME = 150; // milliseconds

// Game state
let gameState = 'menu'; // 'menu', 'playing', 'paused', 'gameOver', 'win'
let player;
let platforms = [];
let enemies = [];
let coins = [];
let projectiles = [];
let backgroundObjects = [];
let traps = [];
let camera = { x: 0, y: 0 };
let collectedCoins = 0;
let totalCoins = 0;
let playerHealth = 100;
let bgColor;
let musicVolume = 0.5;
let soundVolume = 0.7;
let isMobile = false;
let particles = [];
let sunPos = { x: 100, y: 100 }; // Sun position

// Player animation states
const PLAYER_ANIM_STATES = {
    IDLE: 0,
    WALKING: 1,
    JUMPING: 2
};
let playerAnimState = PLAYER_ANIM_STATES.IDLE;
let animFrame = 0;
let lastAnimUpdate = 0;
let animSpeed = 100; // milliseconds per frame
let hitSound;
// Preload function for assets
function preload() {
    hitSound = loadSound('bg.mp3');
}

// Setup function
function setup() {
    const canvas = createCanvas(800, 500);
    canvas.parent('game-container');
    bgColor = color(135, 206, 235); // Sky blue

    // Check for mobile device
    isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    if (isMobile) {
        document.querySelector('.touch-controls').style.display = 'flex';
        document.querySelector('.jump-button').style.display = 'flex';

        // Add touch event listeners
        document.getElementById('left-btn').addEventListener('touchstart', () => {
            player.velX = -PLAYER_SPEED;
            player.facingRight = false;
        });
        document.getElementById('left-btn').addEventListener('touchend', () => {
            if (player.velX < 0) player.velX = 0;
        });

        document.getElementById('right-btn').addEventListener('touchstart', () => {
            player.velX = PLAYER_SPEED;
            player.facingRight = true;
        });
        document.getElementById('right-btn').addEventListener('touchend', () => {
            if (player.velX > 0) player.velX = 0;
        });

        document.getElementById('jump-btn').addEventListener('touchstart', () => {
            if (!player.jumping) {
                player.velY = JUMP_FORCE;
                player.jumping = true;
                createParticles(player.x + player.width / 2, player.y, 15, color(50, 150, 200), 'jump');
            }
        });

        // Update instructions for mobile
        document.querySelector('.instructions').textContent =
            'Touch arrows to move | Touch jump button to jump | P to pause | Collect all coins to win!';
    }

    setupGame();
}

// Initialize game objects
function setupGame() {
    // Create player with animation states
    player = {
        x: 100,
        y: 300,
        width: PLAYER_SIZE,
        height: PLAYER_SIZE * 1.2,
        velX: 0,
        velY: 0,
        jumping: false,
        facingRight: true,
        color: color(50, 150, 200),
        health: playerHealth,
        lastShot: 0,
        shootCooldown: 500,
        invincible: false,
        invincibleTimer: 0
    };

    // Reset game state
    collectedCoins = 0;
    platforms = [];
    enemies = [];
    coins = [];
    projectiles = [];
    backgroundObjects = [];
    traps = [];
    particles = [];
    camera = { x: 0, y: 0 };
    playerAnimState = PLAYER_ANIM_STATES.IDLE;
    animFrame = 0;

    // Create platforms
    createPlatforms();

    // Create enemies
    createEnemies();

    // Create coins
    createCoins();

    // Create background objects
    createBackgroundObjects();

    // Create traps
    createTraps();
}

// Create platforms
function createPlatforms() {
    // Ground
    platforms.push({
        x: 0,
        y: height - 50,
        width: width * 3,
        height: 50,
        color: color(34, 139, 34),
        moving: false
    });

    // Platforms
    platforms.push({ x: 300, y: 400, width: 200, height: 20, color: color(160, 120, 40), moving: false });
    platforms.push({ x: 600, y: 350, width: 150, height: 20, color: color(160, 120, 40), moving: false });
    platforms.push({ x: 900, y: 300, width: 200, height: 20, color: color(160, 120, 40), moving: false });
    platforms.push({ x: 1200, y: 250, width: 150, height: 20, color: color(160, 120, 40), moving: false });

    // Moving platforms
    platforms.push({
        x: 500,
        y: 320,
        width: 100,
        height: 15,
        color: color(70, 130, 180),
        moving: true,
        direction: 1,
        speed: 1.5,
        minX: 450,
        maxX: 650
    });

    platforms.push({
        x: 800,
        y: 270,
        width: 100,
        height: 15,
        color: color(70, 130, 180),
        moving: true,
        direction: -1,
        speed: 2,
        minX: 700,
        maxX: 900
    });
}

// Create enemies
function createEnemies() {
    // Patrolling enemy
    enemies.push({
        x: 400,
        y: height - 80,
        width: 30,
        height: 40,
        color: color(220, 20, 60),
        type: 'patrol',
        direction: -1,
        speed: ENEMY_SPEED,
        minX: 350,
        maxX: 700,
        animFrame: 0,
        lastAnimUpdate: 0
    });

    // Flying enemy
    enemies.push({
        x: 1000,
        y: 200,
        width: 30,
        height: 30,
        color: color(138, 43, 226),
        type: 'flying',
        direction: 1,
        speed: ENEMY_SPEED * 0.8,
        minY: 150,
        maxY: 250,
        animFrame: 0,
        lastAnimUpdate: 0
    });

    // Shooting enemy
    enemies.push({
        x: 1300,
        y: height - 90,
        width: 30,
        height: 40,
        color: color(255, 165, 0),
        type: 'shooter',
        direction: 1,
        lastShot: 0,
        shootCooldown: 2000,
        animFrame: 0,
        lastAnimUpdate: 0
    });
}

// Create coins
function createCoins() {
    const coinPositions = [
        { x: 350, y: 370 },
        { x: 650, y: 320 },
        { x: 950, y: 270 },
        { x: 1250, y: 220 },
        { x: 550, y: 290 },
        { x: 750, y: 240 },
        { x: 1100, y: 180 },
        { x: 1350, y: 200 }
    ];

    for (let pos of coinPositions) {
        coins.push({
            x: pos.x,
            y: pos.y,
            size: COIN_SIZE,
            rotation: 0,
            collected: false,
            color: color(255, 215, 0),
            shine: 0,
            shineSpeed: 0.05
        });
    }

    totalCoins = coins.length;
}

// Create background objects
function createBackgroundObjects() {
    // Create mountains
    backgroundObjects.push({ type: 'mountain', x: 200, y: height - 150, width: 300, height: 150, color: color(120, 80, 40) });
    backgroundObjects.push({ type: 'mountain', x: 600, y: height - 120, width: 200, height: 120, color: color(110, 70, 30) });
    backgroundObjects.push({ type: 'mountain', x: 1100, y: height - 180, width: 350, height: 180, color: color(130, 90, 50) });

    // Create trees
    backgroundObjects.push({ type: 'tree', x: 250, y: height - 100, width: 40, height: 100, color: color(34, 139, 34) });
    backgroundObjects.push({ type: 'tree', x: 450, y: height - 120, width: 35, height: 110, color: color(50, 205, 50) });
    backgroundObjects.push({ type: 'tree', x: 800, y: height - 90, width: 30, height: 90, color: color(60, 179, 113) });
    backgroundObjects.push({ type: 'tree', x: 1250, y: height - 100, width: 45, height: 120, color: color(34, 139, 34) });

    // Create clouds
    backgroundObjects.push({ type: 'cloud', x: 100, y: 80, width: 120, height: 60, color: color(240, 240, 240) });
    backgroundObjects.push({ type: 'cloud', x: 400, y: 60, width: 150, height: 70, color: color(250, 250, 250) });
    backgroundObjects.push({ type: 'cloud', x: 700, y: 100, width: 100, height: 50, color: color(230, 230, 230) });
    backgroundObjects.push({ type: 'cloud', x: 1000, y: 70, width: 130, height: 65, color: color(245, 245, 245) });
}

// Create traps
function createTraps() {
    traps.push({ x: 200, y: height - 50, width: 40, height: 15, color: color(255, 0, 0), active: true });
    traps.push({ x: 900, y: height - 50, width: 40, height: 15, color: color(255, 0, 0), active: true });
    traps.push({ x: 1100, y: height - 50, width: 40, height: 15, color: color(255, 0, 0), active: true });
    traps.push({ x: 1400, y: height - 50, width: 40, height: 15, color: color(255, 0, 0), active: true });
}

// Particle class for visual effects
class Particle {
    constructor(x, y, size, color, type) {
        this.x = x;
        this.y = y;
        this.size = random(3, size);
        this.color = color;
        this.lifetime = PARTICLE_LIFETIME;
        this.velX = random(-2, 2);
        this.velY = random(-2, 2);
        this.type = type;

        // Different properties for different particle types
        if (type === 'jump') {
            this.velY = -random(3, 5);
            this.velX = random(-1, 1);
        } else if (type === 'land') {
            this.velY = random(1, 3);
            this.velX = random(-2, 2);
        } else if (type === 'coin') {
            this.velY = -random(2, 4);
            this.velX = random(-2, 2);
            this.size = random(5, 10);
        } else if (type === 'damage') {
            this.velX = random(-3, 3) * (player.facingRight ? 1 : -1);
            this.velY = random(-3, 0);
            this.lifetime = random(80, 120);
        }
    }

    update() {
        this.x += this.velX;
        this.y += this.velY;
        this.lifetime -= 1;

        // Add gravity to particles
        this.velY += 0.1;

        // Fade out as lifetime decreases
        this.color.setAlpha(map(this.lifetime, 0, PARTICLE_LIFETIME, 0, 255));

        // Shrink as lifetime decreases for certain types
        if (this.type === 'coin' || this.type === 'damage') {
            this.size = map(this.lifetime, 0, PARTICLE_LIFETIME, 0, this.size);
        }
    }

    draw() {
        noStroke();
        fill(this.color);

        if (this.type === 'jump' || this.type === 'land' || this.type === 'damage') {
            ellipse(this.x, this.y, this.size);
        } else if (this.type === 'coin') {
            // Coin particles have a special shape
            push();
            rotate(random(TWO_PI));
            rect(this.x - this.size / 2, this.y - this.size / 4, this.size, this.size / 2);
            pop();
        }
    }

    isAlive() {
        return this.lifetime > 0;
    }
}

// Create particle effects
function createParticles(x, y, count, color, type) {
    for (let i = 0; i < count; i++) {
        particles.push(new Particle(x, y, 8, color, type));
    }
}

// Draw function - main game loop
function draw() {
    if (gameState === 'menu') {
        drawMenu();
    } else if (gameState === 'playing') {
        updateGame();
        drawGame();
    } else if (gameState === 'paused') {
        drawGame();
        drawPauseMenu();
    } else if (gameState === 'gameOver') {
        drawGame();
        drawGameOver();
    } else if (gameState === 'win') {
        drawGame();
        drawWinScreen();
    }
}

// Update game state
function updateGame() {
    // Update player
    updatePlayer();

    // Update enemies
    updateEnemies();

    // Update projectiles
    updateProjectiles();

    // Update moving platforms
    updatePlatforms();

    // Update coins
    updateCoins();

    // Update particles
    updateParticles();

    // Update player animation state
    updatePlayerAnimation();

    // Update camera position to follow player
    camera.x = player.x - width / 3;
    camera.x = constrain(camera.x, 0, width * 2 - width);
}

// Update particles
function updateParticles() {
    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        if (!particles[i].isAlive()) {
            particles.splice(i, 1);
        }
    }
}

// Update player animation state
function updatePlayerAnimation() {
    const currentTime = millis();

    // Update animation frame based on player state
    if (player.velY !== 0) {
        playerAnimState = PLAYER_ANIM_STATES.JUMPING;
    } else if (player.velX !== 0) {
        playerAnimState = PLAYER_ANIM_STATES.WALKING;
    } else {
        playerAnimState = PLAYER_ANIM_STATES.IDLE;
    }

    // Animate walking only if in walking state
    if (playerAnimState === PLAYER_ANIM_STATES.WALKING && currentTime - lastAnimUpdate > animSpeed) {
        animFrame = (animFrame + 1) % 4; // 4 frames for walking animation
        lastAnimUpdate = currentTime;
    }

    // Update enemy animations
    for (let enemy of enemies) {
        if (currentTime - enemy.lastAnimUpdate > animSpeed * 0.8) {
            enemy.animFrame = (enemy.animFrame + 1) % 3; // 3 frames for enemy animation
            enemy.lastAnimUpdate = currentTime;
        }
    }
}

// Draw the game world
function drawGame() {
    background(bgColor);

    // Draw sun and sun rays
    drawSun();

    // Translate based on camera position
    push();
    translate(-camera.x, 0);

    // Draw background objects (only if on screen)
    drawBackgroundObjects();

    // Draw platforms (only if on screen)
    drawPlatforms();

    // Draw traps (only if on screen)
    drawTraps();

    // Draw coins (only if on screen and not collected)
    drawCoins();

    // Draw enemies (only if on screen)
    drawEnemies();

    // Draw projectiles (only if on screen)
    drawProjectiles();

    // Draw particles
    drawParticles();

    // Draw player
    drawPlayer();

    // Draw pits
    drawPits();

    pop();

    // Draw HUD (not affected by camera)
    drawHUD();
}

// Draw sun and sun rays
function drawSun() {
    // Sun
    fill(255, 255, 0);
    ellipse(sunPos.x, sunPos.y, 40, 40);

    // Sun rays
    stroke(255, 255, 0);
    strokeWeight(2);
    for (let i = 0; i < 12; i++) {
        let angle = i * TWO_PI / 12;
        let length = random(60, 100);
        line(
            sunPos.x, sunPos.y,
            sunPos.x + cos(angle) * length,
            sunPos.y + sin(angle) * length
        );
    }
    noStroke();
}

// Draw particles
function drawParticles() {
    for (let particle of particles) {
        particle.draw();
    }
}

// Draw menu screen
function drawMenu() {
    background(25, 25, 60);

    // Title
    fill(50, 200, 255);
    textSize(60);
    textAlign(CENTER, CENTER);
    text('PLATFORMER QUEST', width / 2, 100);

    // Play button
    fill(50, 180, 100);
    rect(width / 2 - 100, 200, 200, 60, 10);
    fill(255);
    textSize(30);
    text('PLAY GAME', width / 2, 230);

    // Instructions
    fill(200, 200, 255);
    textSize(20);
    text('Collect all coins to win!', width / 2, 300);
    text('Avoid enemies and traps!', width / 2, 330);

    // Detailed win condition
    fill(180, 255, 180);
    textSize(16);
    text('Collect all 8 coins scattered across the level to complete the quest.', width / 2, 360);

    // Controls
    fill(180, 180, 255);
    textSize(18);
    if (isMobile) {
        text('Controls: Touch arrows to move | Touch jump to jump | P to pause', width / 2, 400);
    } else {
        text('Controls: Arrow Keys to Move | Space to Jump | P to Pause', width / 2, 400);
    }

    // Sound controls
    drawSoundControls(width / 2 - 150, 450);
}

// Draw pause menu
function drawPauseMenu() {
    fill(0, 0, 0, 180);
    rect(0, 0, width, height);

    fill(255, 255, 100);
    textSize(40);
    textAlign(CENTER, CENTER);
    text('GAME PAUSED', width / 2, height / 2 - 50);

    fill(200, 200, 255);
    textSize(24);
    text('Press P to Resume', width / 2, height / 2 + 20);

    drawSoundControls(width / 2 - 150, height / 2 + 80);
}

// Draw game over screen
function drawGameOver() {
    fill(0, 0, 0, 180);
    rect(0, 0, width, height);

    fill(255, 50, 50);
    textSize(50);
    textAlign(CENTER, CENTER);
    text('GAME OVER', width / 2, height / 2 - 50);

    fill(200, 200, 255);
    textSize(24);
    text('Press R to Restart', width / 2, height / 2 + 20);
}

// Draw win screen
function drawWinScreen() {
    fill(0, 0, 0, 180);
    rect(0, 0, width, height);

    fill(50, 255, 100);
    textSize(50);
    textAlign(CENTER, CENTER);
    text('VICTORY!', width / 2, height / 2 - 50);

    fill(200, 200, 255);
    textSize(24);
    text('You collected all coins!', width / 2, height / 2 + 20);
    text('Press R to Restart', width / 2, height / 2 + 60);
}

// Draw sound controls
function drawSoundControls(x, y) {
    fill(70, 70, 150);
    rect(x, y, 300, 30, 5);

    // Music volume slider
    fill(100, 200, 255);
    rect(x + 10, y, musicVolume * 280, 30, 5);
    fill(255);
    textSize(16);
    textAlign(LEFT, CENTER);
    text('Music Volume', x, y - 20);

    // Sound volume slider
    fill(70, 70, 150);
    rect(x, y + 50, 300, 30, 5);
    fill(100, 255, 150);
    rect(x + 10, y + 50, soundVolume * 280, 30, 5);
    fill(255);
    text('Sound Volume', x, y + 30);
}

// Update player position and state
function updatePlayer() {
    // Apply gravity
    player.velY += GRAVITY;
    player.y += player.velY;

    // Move player horizontally
    player.x += player.velX;

    // Keep player in bounds
    player.x = constrain(player.x, 0, width * 2 - player.width);

    // Check if player is invincible
    if (player.invincible) {
        player.invincibleTimer -= 1;
        if (player.invincibleTimer <= 0) {
            player.invincible = false;
        }
    }

    // Check platform collisions
    let onPlatform = false;
    for (let platform of platforms) {
        if (isObjectOnScreen(platform) &&  // Viewport culling
            player.x + player.width > platform.x &&
            player.x < platform.x + platform.width &&
            player.y + player.height > platform.y &&
            player.y + player.height < platform.y + platform.height / 2 &&
            player.velY > 0) {

            player.y = platform.y - player.height;
            player.velY = 0;
            player.jumping = false;
            onPlatform = true;

            // Create landing particles
            if (player.velY > 3) { // Only create particles for significant falls
                createParticles(player.x + player.width / 2, player.y + player.height, 10, color(100, 100, 100), 'land');
            }
        }
    }

    // Check if player fell off the world
    if (player.y > height + 100) {
        player.health = 0;
    }

    // Check trap collisions (with invincibility)
    for (let trap of traps) {
        if (isObjectOnScreen(trap) &&  // Viewport culling
            trap.active &&
            player.x + player.width > trap.x &&
            player.x < trap.x + trap.width &&
            player.y + player.height > trap.y &&
            player.y < trap.y + trap.height &&
            !player.invincible) {

            player.health -= 5;
            player.invincible = true;
            player.invincibleTimer = INVINCIBILITY_DURATION;

            // Create damage particles
            createParticles(player.x + player.width / 2, player.y + player.height / 2, 15, color(255, 50, 50), 'damage');

            if (player.health <= 0) {
                gameState = 'gameOver';
            }
        }
    }

    // Check coin collisions
    for (let coin of coins) {
        if (!coin.collected && isObjectOnScreen(coin) &&  // Viewport culling
            dist(player.x + player.width / 2, player.y + player.height / 2,
                coin.x, coin.y) < (player.width / 2 + coin.size / 2)) {

            coin.collected = true;
            collectedCoins++;

            // Create coin particles
            createParticles(coin.x, coin.y, 20, color(255, 215, 0), 'coin');

            if (collectedCoins >= totalCoins) {
                gameState = 'win';
            }
        }
    }

    // Check enemy collisions (with invincibility)
    for (let enemy of enemies) {
        if (isObjectOnScreen(enemy) &&  // Viewport culling
            player.x + player.width > enemy.x &&
            player.x < enemy.x + enemy.width &&
            player.y + player.height > enemy.y &&
            player.y < enemy.y + enemy.height &&
            !player.invincible) {

            player.health -= 2;
            player.invincible = true;
            player.invincibleTimer = INVINCIBILITY_DURATION;

            // Create damage particles
            createParticles(player.x + player.width / 2, player.y + player.height / 2, 15, color(255, 50, 50), 'damage');

            if (player.health <= 0) {
                gameState = 'gameOver';
            }
        }
    }

    // Check projectile collisions (with invincibility)
    for (let i = projectiles.length - 1; i >= 0; i--) {
        let p = projectiles[i];
        if (isObjectOnScreen(p) &&  // Viewport culling

            player.x + player.width > p.x &&
            player.x < p.x + p.size &&
            player.y + player.height > p.y &&
            player.y < p.y + p.size &&
            !player.invincible) {
            hitSound.play();
            player.health -= 10;
            projectiles.splice(i, 1);
            player.invincible = true;
            player.invincibleTimer = INVINCIBILITY_DURATION;

            // Create damage particles
            createParticles(player.x + player.width / 2, player.y + player.height / 2, 15, color(255, 50, 50), 'damage');

            if (player.health <= 0) {
                gameState = 'gameOver';
            }
        }
    }
}

// Update enemies
function updateEnemies() {
    for (let enemy of enemies) {
        if (isObjectOnScreen(enemy)) {  // Viewport culling
            if (enemy.type === 'patrol') {
                // Patrol left and right
                enemy.x += enemy.direction * enemy.speed;

                if (enemy.x < enemy.minX || enemy.x + enemy.width > enemy.maxX) {
                    enemy.direction *= -1;
                }
            } else if (enemy.type === 'flying') {
                // Fly up and down
                enemy.y += enemy.direction * enemy.speed;

                if (enemy.y < enemy.minY || enemy.y > enemy.maxY) {
                    enemy.direction *= -1;
                }
            } else if (enemy.type === 'shooter') {
                // Shoot at player periodically
                if (millis() - enemy.lastShot > enemy.shootCooldown) {
                    let angle = atan2(player.y - enemy.y, player.x - enemy.x);
                    projectiles.push({
                        x: enemy.x + enemy.width / 2,
                        y: enemy.y + enemy.height / 2,
                        size: 10,
                        velX: cos(angle) * PROJECTILE_SPEED,
                        velY: sin(angle) * PROJECTILE_SPEED,
                        color: color(255, 200, 0)
                    });
                    enemy.lastShot = millis();
                }
            }
        }
    }
}

// Update projectiles
function updateProjectiles() {
    for (let i = projectiles.length - 1; i >= 0; i--) {
        let p = projectiles[i];
        p.x += p.velX;
        p.y += p.velY;

        // Remove projectiles that go off screen
        if (!isObjectOnScreen(p)) {
            projectiles.splice(i, 1);
        }
    }
}

// Update platforms
function updatePlatforms() {
    for (let platform of platforms) {
        if (platform.moving) {
            platform.x += platform.direction * platform.speed;

            if (platform.x < platform.minX || platform.x + platform.width > platform.maxX) {
                platform.direction *= -1;
            }
        }
    }
}

// Update coins (rotation and shine)
function updateCoins() {
    for (let coin of coins) {
        if (!coin.collected && isObjectOnScreen(coin)) {  // Viewport culling
            coin.rotation += COIN_ROTATION_SPEED;
            coin.shine = (coin.shine + coin.shineSpeed) % TWO_PI;
        }
    }
}

// Draw player with animations
function drawPlayer() {
    // Apply invincibility flashing effect
    if (player.invincible && floor(millis() / 100) % 2 === 0) {
        return; // Skip drawing every other frame for flashing effect
    }

    let mainColor = player.color;
    let secondaryColor = color(30, 100, 150);

    // Body
    fill(mainColor);
    rect(player.x, player.y, player.width, player.height, 5);

    // Head
    fill(240, 200, 150);
    ellipse(player.x + player.width / 2, player.y - 5, 25, 25);

    // Eyes - different expressions based on state
    fill(0);
    let eyeOffset = player.facingRight ? 5 : -5;
    if (playerAnimState === PLAYER_ANIM_STATES.JUMPING) {
        // Jumping expression - eyes wide open
        ellipse(player.x + player.width / 2 - eyeOffset / 2, player.y - 8, 6, 6);
        ellipse(player.x + player.width / 2 + eyeOffset / 2, player.y - 8, 6, 6);
    } else if (playerAnimState === PLAYER_ANIM_STATES.WALKING) {
        // Walking expression - eyes looking forward
        ellipse(player.x + player.width / 2 - eyeOffset / 2, player.y - 5, 5, 5);
        ellipse(player.x + player.width / 2 + eyeOffset / 2, player.y - 5, 5, 5);
    } else {
        // Idle expression - relaxed eyes
        ellipse(player.x + player.width / 2 - eyeOffset / 2, player.y - 3, 4, 4);
        ellipse(player.x + player.width / 2 + eyeOffset / 2, player.y - 3, 4, 4);
    }

    // Mouth - different based on state
    fill(200, 50, 50);
    if (playerAnimState === PLAYER_ANIM_STATES.JUMPING) {
        // Jumping - open mouth
        arc(player.x + player.width / 2, player.y + 5, 12, 8, 0, PI);
    } else if (playerAnimState === PLAYER_ANIM_STATES.WALKING) {
        // Walking - small smile
        arc(player.x + player.width / 2, player.y + 5, 10, 6, 0, PI);
    } else {
        // Idle - closed mouth
        line(player.x + player.width / 2 - 5, player.y + 5, player.x + player.width / 2 + 5, player.y + 5);
    }

    // Walking legs animation
    if (playerAnimState === PLAYER_ANIM_STATES.WALKING) {
        // Left leg
        fill(secondaryColor);
        if (animFrame % 2 === 0) {
            rect(player.x + 5, player.y + player.height, 8, 10); // Forward leg
        } else {
            rect(player.x + 5, player.y + player.height - 5, 8, 15); // Back leg
        }

        // Right leg
        if (animFrame % 2 === 0) {
            rect(player.x + player.width - 13, player.y + player.height - 5, 8, 15); // Back leg
        } else {
            rect(player.x + player.width - 13, player.y + player.height, 8, 10); // Forward leg
        }
    } else {
        // Idle legs
        fill(secondaryColor);
        rect(player.x + 5, player.y + player.height, 8, 10);
        rect(player.x + player.width - 13, player.y + player.height, 8, 10);
    }

    // Health bar
    fill(255, 0, 0);
    rect(player.x, player.y - 30, player.width, 5);
    fill(0, 255, 0);
    rect(player.x, player.y - 30, player.width * (player.health / 100), 5);
}

// Draw platforms (with viewport culling)
function drawPlatforms() {
    for (let platform of platforms) {
        if (isObjectOnScreen(platform)) {
            fill(platform.color);
            rect(platform.x, platform.y, platform.width, platform.height);

            // Platform top
            fill(platform.color.levels[0] - 20, platform.color.levels[1] - 20, platform.color.levels[2] - 20);
            rect(platform.x, platform.y, platform.width, 5);
        }
    }
}

// Draw enemies with animations
function drawEnemies() {
    for (let enemy of enemies) {
        if (isObjectOnScreen(enemy)) {
            fill(enemy.color);

            if (enemy.type === 'flying') {
                // Draw flying enemy as a bat-like shape with animation
                let wingOffset = sin(frameCount * 0.1 + enemy.animFrame * 0.5) * 5;
                ellipse(enemy.x + enemy.width / 2, enemy.y + enemy.height / 2, enemy.width, enemy.height);

                // Animated wings
                triangle(
                    enemy.x + enemy.width / 2, enemy.y + enemy.height / 2,
                    enemy.x - 15 + sin(enemy.animFrame * 0.3) * 5, enemy.y - 10 + wingOffset,
                    enemy.x - 5, enemy.y + enemy.height / 2
                );
                triangle(
                    enemy.x + enemy.width / 2, enemy.y + enemy.height / 2,
                    enemy.x + enemy.width + 15 - sin(enemy.animFrame * 0.3) * 5, enemy.y - 10 + wingOffset,
                    enemy.x + enemy.width + 5, enemy.y + enemy.height / 2
                );
            } else {
                // Draw ground enemies with animated legs
                rect(enemy.x, enemy.y, enemy.width, enemy.height, 5);

                // Enemy eyes
                fill(0);
                ellipse(enemy.x + 8, enemy.y + 12, 5, 5);
                ellipse(enemy.x + enemy.width - 8, enemy.y + 12, 5, 5);

                // Animated legs
                fill(enemy.color.levels[0] - 30, enemy.color.levels[1] - 30, enemy.color.levels[2] - 30);
                if (enemy.animFrame % 2 === 0) {
                    rect(enemy.x + 5, enemy.y + enemy.height, 8, 10); // Left leg forward
                    rect(enemy.x + enemy.width - 13, enemy.y + enemy.height - 5, 8, 15); // Right leg back
                } else {
                    rect(enemy.x + 5, enemy.y + enemy.height - 5, 8, 15); // Left leg back
                    rect(enemy.x + enemy.width - 13, enemy.y + enemy.height, 8, 10); // Right leg forward
                }
            }
        }
    }
}

// Draw projectiles
function drawProjectiles() {
    for (let p of projectiles) {
        if (isObjectOnScreen(p)) {
            fill(p.color);
            ellipse(p.x, p.y, p.size);
        }
    }
}

// Draw coins with shine effect
function drawCoins() {
    for (let coin of coins) {
        if (!coin.collected && isObjectOnScreen(coin)) {
            push();
            translate(coin.x, coin.y);
            rotate(coin.rotation);

            fill(coin.color);
            ellipse(0, 0, coin.size);

            // Shine effect
            fill(255, 255, 200, 150);
            let shineX = cos(coin.shine) * coin.size * 0.3;
            let shineY = sin(coin.shine) * coin.size * 0.3;
            ellipse(shineX, shineY, coin.size * 0.4, coin.size * 0.2);

            fill(200, 150, 0);
            ellipse(0, 0, coin.size * 0.7);

            fill(coin.color);
            rect(-coin.size * 0.15, -coin.size * 0.4, coin.size * 0.3, coin.size * 0.8);

            pop();
        }
    }
}

// Draw background objects (with viewport culling)
function drawBackgroundObjects() {
    for (let obj of backgroundObjects) {
        if (isObjectOnScreen(obj)) {
            fill(obj.color);

            if (obj.type === 'mountain') {
                // Draw mountain as a triangle
                triangle(
                    obj.x, obj.y + obj.height,
                    obj.x + obj.width / 2, obj.y,
                    obj.x + obj.width, obj.y + obj.height
                );
            } else if (obj.type === 'tree') {
                // Draw tree trunk
                fill(101, 67, 33);
                rect(obj.x + obj.width / 3, obj.y + obj.height / 2, obj.width / 3, obj.height / 2);

                // Draw tree top with animated leaves
                fill(obj.color);
                ellipse(obj.x + obj.width / 2, obj.y + obj.height / 3 + sin(frameCount * 0.05) * 5,
                    obj.width + sin(frameCount * 0.03) * 3, obj.height * 0.8 + sin(frameCount * 0.02) * 2);
            } else if (obj.type === 'cloud') {
                // Draw cloud as several circles with slight animation
                ellipse(obj.x + obj.width * 0.3 + sin(frameCount * 0.01) * 5,
                    obj.y + obj.height * 0.5 + sin(frameCount * 0.01) * 3,
                    obj.width * 0.6, obj.height * 0.8);
                ellipse(obj.x + obj.width * 0.7 + sin(frameCount * 0.01) * 5,
                    obj.y + obj.height * 0.5 + sin(frameCount * 0.01) * 3,
                    obj.width * 0.6, obj.height * 0.8);
                ellipse(obj.x + obj.width * 0.5 + sin(frameCount * 0.01) * 5,
                    obj.y + obj.height * 0.3 + sin(frameCount * 0.01) * 3,
                    obj.width * 0.6, obj.height * 0.8);
            }
        }
    }
}

// Draw traps with visual feedback
function drawTraps() {
    for (let trap of traps) {
        if (isObjectOnScreen(trap) && trap.active) {
            fill(trap.color);

            // Draw spikes with pulsing animation
            let pulse = sin(frameCount * 0.1) * 2 + 1;
            for (let i = 0; i < 4; i++) {
                let x = trap.x + i * trap.width / 4;
                triangle(
                    x, trap.y + trap.height,
                    x + trap.width / 8 * pulse, trap.y,
                    x + trap.width / 4 * pulse, trap.y + trap.height
                );
            }

            // Glow effect for dangerous areas
            noFill();
            stroke(trap.color, 100);
            strokeWeight(3);
            circle(trap.x + trap.width / 2, trap.y + trap.height / 2, trap.width * 1.5);
            noStroke();
        }
    }
}

// Draw pits
function drawPits() {
    // Draw pit at the end of the level
    fill(0);
    rect(width * 2 - 200, height - 50, 200, 50);
    fill(40, 40, 40);
    for (let i = 0; i < 4; i++) {
        ellipse(width * 2 - 200 + i * 50 + 25, height - 25, 30, 10);
    }
}

// Draw HUD (Heads Up Display)
function drawHUD() {
    // Coin counter
    fill(255, 215, 0);
    textSize(24);
    textAlign(LEFT, TOP);
    text(`Coins: ${collectedCoins}/${totalCoins}`, 20, 20);

    // Health bar
    fill(255, 0, 0);
    rect(20, 60, 200, 20);
    fill(0, 255, 0);
    rect(20, 60, 200 * (player.health / 100), 20);
    fill(255);
    textSize(16);
    text(`Health: ${floor(player.health)}%`, 30, 62);

    // Invincibility timer
    if (player.invincible) {
        fill(255, 255, 0);
        textSize(16);
        text('INVINCIBLE', 20, 90);
    }
}

// Check if an object is on screen (viewport culling)
function isObjectOnScreen(obj) {
    // For simple objects with x, y, width, height
    return obj.x < camera.x + width * 1.5 &&
        obj.x + (obj.width || 0) > camera.x - width * 0.5 &&
        obj.y < height * 1.5 &&
        obj.y + (obj.height || 0) > 0;
}

// Handle key presses
function keyPressed() {
    if (gameState === 'playing') {
        if (key === ' ' && !player.jumping) {
            player.velY = JUMP_FORCE;
            player.jumping = true;
            createParticles(player.x + player.width / 2, player.y, 15, color(50, 150, 200), 'jump');
        } else if (keyCode === LEFT_ARROW) {
            player.velX = -PLAYER_SPEED;
            player.facingRight = false;
        } else if (keyCode === RIGHT_ARROW) {
            player.velX = PLAYER_SPEED;
            player.facingRight = true;
        } else if (key === 'p' || key === 'P') {
            gameState = 'paused';
        }
    } else if (gameState === 'paused') {
        if (key === 'p' || key === 'P') {
            gameState = 'playing';
        }
    } else if (gameState === 'menu') {
        if (key === ' ') {
            gameState = 'playing';
        }
    } else if (gameState === 'gameOver' || gameState === 'win') {
        if (key === 'r' || key === 'R') {
            setupGame();
            gameState = 'playing';
        }
    }
}

// Handle key releases
function keyReleased() {
    if (keyCode === LEFT_ARROW && player.velX < 0) {
        player.velX = 0;
    } else if (keyCode === RIGHT_ARROW && player.velX > 0) {
        player.velX = 0;
    }
}

// Handle mouse clicks for menu buttons
function mouseClicked() {
    if (gameState === 'menu') {
        // Check if play button is clicked
        if (mouseX > width / 2 - 100 && mouseX < width / 2 + 100 &&
            mouseY > 200 && mouseY < 260) {
            gameState = 'playing';
        }
    }
}
